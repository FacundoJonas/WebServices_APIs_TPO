package ar.edu.uade.api.deliverygo.model;
import jakarta.persistence.*;


@Entity
@Table(name="comercios")
public class Comercio {

 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 private Long id;

 @Column(nullable=false)
 private String nombre;

 @Column(nullable=false,unique=true)
 private String cuit;

 @Column(nullable=false)
 private String email;

 @Column(nullable=false)
 private Boolean activo;

 protected Comercio(){

 }

 public Comercio(String n,String c,String e,Boolean a){
  nombre=n;cuit=c;email=e;activo=a;
 }

 @Override
 public String toString(){
  return "Comercio{id="+id+", nombre='"+nombre+"', activo="+activo+"}";
 }
}