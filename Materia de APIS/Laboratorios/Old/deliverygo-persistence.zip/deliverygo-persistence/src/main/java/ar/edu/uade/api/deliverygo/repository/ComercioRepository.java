package ar.edu.uade.api.deliverygo.repository;
import ar.edu.uade.api.deliverygo.model.Comercio; import org.springframework.data.jpa.repository.JpaRepository;
public interface ComercioRepository extends JpaRepository<Comercio,Long>{}