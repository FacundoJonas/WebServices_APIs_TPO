package ar.edu.uade.api.deliverygo.config;

import ar.edu.uade.api.deliverygo.model.*;
import ar.edu.uade.api.deliverygo.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;
import java.math.BigDecimal;
import java.util.List;

@Configuration
public class DemoDataLoader {

 @Bean CommandLineRunner demo(ComercioRepository comercioRepository,ProductoRepository productoRepository){

  return args->{

  comercioRepository.save(new Comercio("Burger House","30-11111111-1","burger@deliverygo.com",true));

  comercioRepository.save(new Comercio("Pizzeria Central","30-22222222-2","pizza@deliverygo.com",true));

  productoRepository.save(new Producto("Hamburguesa Clasica","Carne, queso y salsa",new BigDecimal("8500"),20,true));

  productoRepository.save(new Producto("Hamburguesa Doble","Doble carne y queso",new BigDecimal("10500"),15,true));

  productoRepository.save(new Producto("Pizza Muzzarella","Muzzarella y aceitunas",new BigDecimal("12000"),12,true));

  productoRepository.save(new Producto("Pizza Napolitana","Tomate y ajo",new BigDecimal("13500"),8,true));

  productoRepository.save(new Producto("Producto fuera de venta","Ejemplo inactivo",new BigDecimal("3000"),0,false));

  System.out.println("\nTODOS:");

  productoRepository.findAll().forEach(System.out::println);

  System.out.println("\nACTIVOS:");

  productoRepository.findByActivoTrue().forEach(System.out::println);

  Producto p=productoRepository.findById(1L).orElseThrow();
  p.setStock(25);
  productoRepository.save(p);

  productoRepository.findById(5L)
          .ifPresent(productoRepository::delete);

  System.out.println("\nCantidad final: "+ productoRepository.count());
  System.out.println("H2: http://localhost:8090/h2-console");
  System.out.println("JDBC: jdbc:h2:mem:deliverygo | usuario: sa | password: vacio");

   System.out.println("\n=== PRODUCTOS CON PRECIO MENOR A $10.000 ===");
 };
 }}
