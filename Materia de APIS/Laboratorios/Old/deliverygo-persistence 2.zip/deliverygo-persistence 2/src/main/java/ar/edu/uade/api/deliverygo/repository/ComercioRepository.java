package ar.edu.uade.api.deliverygo.repository;

import ar.edu.uade.api.deliverygo.model.Comercio;
import ar.edu.uade.api.deliverygo.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComercioRepository extends JpaRepository<Comercio,Long>{

    List<Comercio> findByNombreContainingIgnoreCase(String nombre);

}