package ar.edu.uade.api.deliverygo.config;

import ar.edu.uade.api.deliverygo.model.Comercio;
import ar.edu.uade.api.deliverygo.model.Producto;
import ar.edu.uade.api.deliverygo.repository.ComercioRepository;
import ar.edu.uade.api.deliverygo.repository.ProductoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Configuration
public class DemoDataLoader {

 @Bean CommandLineRunner demo(ComercioRepository comercioRepository,ProductoRepository productoRepository){

  return args->{

   Comercio burgerHouse = comercioRepository.save(new Comercio("Burger House","30-11111111-1","burger@deliverygo.com",true));

   Comercio pizzeriaCentral =  comercioRepository.save(new Comercio("Pizzeria Central","30-22222222-2","pizza@deliverygo.com",true));
  /*
  *  insert
    into
        comercios
        (activo, cuit, email, nombre, id)
    values
        (?, ?, ?, ?, default)
  *
  * */
  Producto p1 = new Producto("Hamburguesa Clasica","Carne, queso y salsa",new BigDecimal("8500"),20,true, burgerHouse);
  productoRepository.save(p1);

  Producto p2 =  new Producto("Hamburguesa Doble","Doble carne y queso",new BigDecimal("10500"),15,true,pizzeriaCentral);
  productoRepository.save(p2);

  Producto p3 =  new Producto("Pizza Muzzarella","Muzzarella y aceitunas",new BigDecimal("12000"),12,true);
  p3.setComercio(pizzeriaCentral);
   productoRepository.save(p3);

   Producto p4 =  new Producto("Pizza Napolitana","Tomate y ajo",new BigDecimal("13500"),8,true);
  p4.setComercio(pizzeriaCentral);
   productoRepository.save(p4);

   Producto p5 = new Producto("Producto fuera de venta","Ejemplo inactivo",new BigDecimal("3000"),0,true);
  p5.setComercio(pizzeriaCentral);
   productoRepository.save(p5);

  System.out.println("\nTODOS:");

  productoRepository.findAll().forEach(System.out::println);

  System.out.println("\nACTIVOS:");

   System.out.println(
           "\n=== PRODUCTOS ENTRE $8.000 Y $12.000 ==="
   );

   /**
    * findBy | Precio | Between
    *   ↓        ↓         ↓
    * buscar   atributo   entre dos valores
    *
    * SELECT *
    * FROM productos
    * WHERE precio BETWEEN ? AND ?;
    * */

   List<Producto> productosPorRango =
           productoRepository.findByPrecioBetween(
                   new BigDecimal("8500.00"),
                   new BigDecimal("12000.00")
           );

   productosPorRango.forEach(System.out::println);

   System.out.println(
           "\n=== Lista productos que contengan pizzas ==="
   );
   /**
    * findBy | Nombre | Containing | IgnoreCase
    *   ↓        ↓          ↓            ↓
    * buscar   atributo   contiene    ignora
    *                                mayúsculas/
    *                                minúsculas
    *
    *Select * from productos where like '%nombre%';
    *
    */
   List<Producto> resultado =
           productoRepository
                   .findByNombreContainingIgnoreCase("pizza");


   resultado.forEach(System.out::println);


   System.out.println(
           "\n=== PRODUCTOS CON PRECIO MENOR A $10.000 ==="
   );
   /**
    * findBy | Precio | LessThan
    *   ↓        ↓        ↓
    * buscar    campo    operador <
    *
    * SELECT *
    * FROM productos
    * WHERE precio < ?
    *
    */
   List<Producto> productosBaratos =
           productoRepository.findByPrecioLessThan(
                   new BigDecimal("10000.00")
           );
   productosBaratos.forEach(System.out::println);


   productoRepository.findByActivoTrue().forEach(System.out::println);

  Producto p=productoRepository.findById(1L).orElseThrow();
  p.setStock(25);
  productoRepository.save(p);

  productoRepository.findById(5L)
          .ifPresent(productoRepository::delete);




  System.out.println("\nCantidad final: "+ productoRepository.count());



  System.out.println("H2: http://localhost:8089/h2-console");
  System.out.println("JDBC: jdbc:h2:mem:deliverygo | usuario: sa | password: vacio");

   System.out.println("\n=== PRODUCTOS CON PRECIO MENOR A $10.000 ===");
 };
 }}
