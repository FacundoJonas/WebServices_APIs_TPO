package ar.edu.uade.api.deliverygo.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Promocion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;

    private BigDecimal descunto;

    @ManyToMany(mappedBy = "promociones")
    private Set<Usuario> usuarios = new HashSet<>();


    public Promocion() {
    }

    public Promocion(Long id, String nombre, BigDecimal descunto) {
        this.id = id;
        this.nombre = nombre;
        this.descunto = descunto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public BigDecimal getDescunto() {
        return descunto;
    }

    public void setDescunto(BigDecimal descunto) {
        this.descunto = descunto;
    }

    @Override
    public String toString() {
        return "Promocion{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descunto=" + descunto +
                '}';
    }
}
