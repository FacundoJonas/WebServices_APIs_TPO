package ar.edu.uade.api.deliverygo.config;
import ar.edu.uade.api.deliverygo.model.*; import ar.edu.uade.api.deliverygo.repository.*;
import org.springframework.boot.CommandLineRunner; import org.springframework.context.annotation.*; import java.math.BigDecimal;
@Configuration public class DemoDataLoader {
 @Bean CommandLineRunner demo(ComercioRepository cr,ProductoRepository pr){return args->{
  cr.save(new Comercio("Burger House","30-11111111-1","burger@deliverygo.com",true));
  cr.save(new Comercio("Pizzeria Central","30-22222222-2","pizza@deliverygo.com",true));
  pr.save(new Producto("Hamburguesa Clasica","Carne, queso y salsa",new BigDecimal("8500"),20,true));
  pr.save(new Producto("Hamburguesa Doble","Doble carne y queso",new BigDecimal("10500"),15,true));
  pr.save(new Producto("Pizza Muzzarella","Muzzarella y aceitunas",new BigDecimal("12000"),12,true));
  pr.save(new Producto("Pizza Napolitana","Tomate y ajo",new BigDecimal("13500"),8,true));
  pr.save(new Producto("Producto fuera de venta","Ejemplo inactivo",new BigDecimal("3000"),0,false));
  System.out.println("\nTODOS:"); pr.findAll().forEach(System.out::println);
  System.out.println("\nACTIVOS:"); pr.findByActivoTrue().forEach(System.out::println);
  Producto p=pr.findById(1L).orElseThrow(); p.setStock(25); pr.save(p);
  pr.findById(5L).ifPresent(pr::delete);
  System.out.println("\nCantidad final: "+pr.count());
  System.out.println("H2: http://localhost:8080/h2-console");
  System.out.println("JDBC: jdbc:h2:mem:deliverygo | usuario: sa | password: vacio");
 };}}
