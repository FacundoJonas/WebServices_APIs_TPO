package ar.edu.uade.api.deliverygo;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class DeliveryGoPersistenceApplication {
 public static void main(String[] args){SpringApplication.run(DeliveryGoPersistenceApplication.class,args);}
}