package ar.edu.uade.api.deliverygo.model;
import jakarta.persistence.*; import java.math.BigDecimal;
@Entity @Table(name="productos") public class Producto {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private String nombre;
 private String descripcion;
 @Column(nullable=false,precision=12,scale=2) private BigDecimal precio;
 @Column(nullable=false) private Integer stock;
 @Column(nullable=false) private Boolean activo;
 protected Producto(){}
 public Producto(String n,String d,BigDecimal p,Integer s,Boolean a){nombre=n;descripcion=d;precio=p;stock=s;activo=a;}
 public void setStock(Integer s){stock=s;}
 @Override public String toString(){return "Producto{id="+id+", nombre='"+nombre+"', precio="+precio+", stock="+stock+", activo="+activo+"}";}
}