package ar.edu.uade.api.deliverygo.services;

import ar.edu.uade.api.deliverygo.dto.ComercioDto;
import ar.edu.uade.api.deliverygo.model.Comercio;
import ar.edu.uade.api.deliverygo.repository.ComercioRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.regex.Pattern;

@Service
public class ComercioServices {


    private final ComercioRepository comercioRepository;

    private static final boolean isComercioActive = true;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
            );

    public ComercioServices(ComercioRepository comercioRepository) {
        this.comercioRepository = comercioRepository;
    }


    @Transactional
    public ComercioDto crearComercio(ComercioDto comercioDto){

        String cuit = comercioDto.getCuitComercio();
        if(Objects.isNull(cuit) || cuit.isEmpty()){
            throw new IllegalArgumentException("El CUIT del comercio no puede ser nulo");
        }
         if(Objects.nonNull(comercioRepository.
                 findByCuit(comercioDto.getCuitComercio())))
         {
             throw new IllegalArgumentException("El CUIT del comercio ya existe");
         }
        String nombreComercio = comercioDto.getNombreComercio();
        if (Objects.isNull(nombreComercio) || nombreComercio.isEmpty()){
            throw new IllegalArgumentException("El nombre del comercio no puede ser nulo");
        }
        String email = validateEmail(comercioDto.getEmailComercio());
        Comercio c = new Comercio(nombreComercio, cuit,email, isComercioActive);
        comercioRepository.save(c);
        return comercioDto;
    }


    private String validateEmail(String email) {
        if (Objects.isNull(email) || email.isEmpty()) {
            throw new IllegalArgumentException("El email del comercio no puede ser nulo");
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new IllegalArgumentException(
                    "El formato del email es inválido"
            );
        }
        return email;
    }


}
