package ar.edu.uade.api.deliverygo.controller;

import ar.edu.uade.api.deliverygo.dto.ComercioDto;
import ar.edu.uade.api.deliverygo.services.ComercioServices;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/comercios")
/*  Post  http://localhost:8080/v1/comercios
*  Entrada
*  {
*        nombreComercio: "Comercio 1",
*        cuitComercio: "20-12345678-9",
*         emailComercio: "ale@gmial.com"
*      }
*Respuesta
*
*
*   Get  http://localhost:8080/v1/comercios/{id}
*   Delete  http://localhost:8080/v1/comercios/{id}
*
* */

public class ComercioController {

    private final ComercioServices comercioServices;

    public ComercioController(ComercioServices comercioServices) {
        this.comercioServices = comercioServices;
    }

    @PostMapping
    public ResponseEntity<ComercioDto> crearComercio(
            @RequestBody ComercioDto comercioDto) {

        comercioServices.crearComercio(comercioDto);
        // Lógica para crear un comercio
        return ResponseEntity.status(HttpStatus.CREATED).body(comercioDto);
    }

}
