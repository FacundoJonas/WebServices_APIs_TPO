package ar.edu.uade.api.deliverygo.repository;

import ar.edu.uade.api.deliverygo.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.util.List;

public interface ProductoRepository extends JpaRepository<Producto,Long>{

 List<Producto> findByActivoTrue();
 List<Producto> findByPrecioLessThan(BigDecimal precio);
 List<Producto> findByNombreContainingIgnoreCase(String nombre);
 List<Producto> findByPrecioBetween(BigDecimal precioMin, BigDecimal precioMax);
}