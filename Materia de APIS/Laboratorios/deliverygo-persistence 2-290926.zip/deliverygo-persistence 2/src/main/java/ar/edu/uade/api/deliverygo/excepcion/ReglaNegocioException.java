package ar.edu.uade.api.deliverygo.excepcion;

public class ReglaNegocioException extends RuntimeException {

    public ReglaNegocioException(String messages){
        super(messages);
    }

}
