package ar.edu.uade.api.deliverygo.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
public class UsuarioPromocion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime fechaPromocionUso;

    private BigDecimal descuentoAplicado;

    @ManyToOne
    private Usuario usuario;

    @ManyToOne
    private Promocion promocion;

    public UsuarioPromocion() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFechaPromocionUso() {
        return fechaPromocionUso;
    }

    public void setFechaPromocionUso(LocalDateTime fechaPromocionUso) {
        this.fechaPromocionUso = fechaPromocionUso;
    }

    public BigDecimal getDescuentoAplicado() {
        return descuentoAplicado;
    }

    public void setDescuentoAplicado(BigDecimal descuentoAplicado) {
        this.descuentoAplicado = descuentoAplicado;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Promocion getPromocion() {
        return promocion;
    }

    public void setPromocion(Promocion promocion) {
        this.promocion = promocion;
    }
}
