package ar.edu.uade.api.deliverygo.config;

import ar.edu.uade.api.deliverygo.dto.*;
import ar.edu.uade.api.deliverygo.model.*;
import ar.edu.uade.api.deliverygo.services.ComercioServices;
import ar.edu.uade.api.deliverygo.services.ProductoServices;
import ar.edu.uade.api.deliverygo.services.PromocionUsuarioServices;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@Configuration
public class DemoDataLoader {

 @Bean CommandLineRunner demo(ProductoServices productoService,
                              PromocionUsuarioServices promocionUsuarioServices,
                              ComercioServices comercioServices) {

  return args->{

   //Comercio burgerHouse = comercioRepository.save(new Comercio("Burger House","30-11111111-1","burger@deliverygo.com",true));

   ComercioDto burgerHouseDto =  comercioServices.
           crearComercio(new
                   ComercioDto(
                           "Burger House",
                   "30-11111111-1",
                   "burger@deliverygo.com"));

   //Comercio pizzeriaCentral =  comercioRepository.save(new Comercio("Pizzeria Central","30-22222222-2","pizza@deliverygo.com",true));

   ComercioDto pizzeriaCentralDto =  comercioServices.
           crearComercio(new
                   ComercioDto(
                   "Pizzeria Central",
                   "30-22222222-2",
                   "burger@deliverygo.com"));

   /*
  *  insert
    into
        comercios
        (activo, cuit, email, nombre, id)
    values
        (?, ?, ?, ?, default)
  *
  * */

   //Producto p1 = new Producto("Hamburguesa Clasica","Carne, queso y salsa",new BigDecimal("8500"),20,true, burgerHouse);
   //productoRepository.save(p1);
   ProductoDto p1 = new ProductoDto("Hamburguesa Clasica",
           8500,"Carne, queso y salsa",20, burgerHouseDto.getCuitComercio());

   productoService.createProducto(p1);

   //Producto p2 =  new Producto("Hamburguesa Doble","Doble carne y queso",new BigDecimal("10500"),15,true,pizzeriaCentral);
   //productoRepository.save(p2);
   ProductoDto p2 = new ProductoDto("Hamburguesa Doble",
           10500,"Doble carne y queso",15, burgerHouseDto.getCuitComercio());
   productoService.createProducto(p2);


   //Producto p3 =  new Producto("Pizza Muzzarella","Muzzarella y aceitunas",new BigDecimal("12000"),12,true);
   //p3.setComercio(pizzeriaCentral);
   //productoRepository.save(p3);
   ProductoDto p3 = new ProductoDto("Pizza Muzzarella",
           12000,"Muzzarella y aceitunas",15, pizzeriaCentralDto.getCuitComercio());
   productoService.createProducto(p3);


   //Producto p4 =  new Producto("Pizza Napolitana","Tomate y ajo",new BigDecimal("13500"),8,true);
  //p4.setComercio(pizzeriaCentral);
   //productoRepository.save(p4);
   ProductoDto p4 = new ProductoDto("Pizza Napolitana",
           13500,"Tomate y ajo",8, pizzeriaCentralDto.getCuitComercio());
   productoService.createProducto(p4);
   //Producto p5 = new Producto("Producto fuera de venta","Ejemplo inactivo",new BigDecimal("3000"),0,true);
   //p5.setComercio(pizzeriaCentral);
   //productoRepository.save(p5);

   ProductoDto p5 = new ProductoDto("Pizza Roquert",
           13500,"Queso Roquert",8, pizzeriaCentralDto.getCuitComercio());
   productoService.createProducto(p5);


   UsuarioDTO usuarioDTO = new UsuarioDTO("ale@gmail.com","Alejandro", "Apellido");
   PromocionDTO promocionDTO = new PromocionDTO("Promocion hamburgeusas",new BigDecimal("300"));
   UsuarioPromocionDTO usuarioPromocionDTO = new UsuarioPromocionDTO(usuarioDTO, promocionDTO, new BigDecimal(10));
   promocionUsuarioServices.agregarUsuarioConSuPromocion(usuarioPromocionDTO);


  System.out.println("\nTODOS:");

   productoService
           .obtenerTodos()
           .forEach(System.out::println);
   //productoRepository.findAll().forEach(System.out::println);

  System.out.println("\nACTIVOS:");

   System.out.println(
           "\n=== PRODUCTOS ENTRE $8.000 Y $12.000 ==="
   );

   /**
    * findBy | Precio | Between
    *   ↓        ↓         ↓
    * buscar   atributo   entre dos valores
    *
    * SELECT *
    * FROM productos
    * WHERE precio BETWEEN ? AND ?;
    * */

   List<Producto> productosPorRango =
           productoService.buscarPorRangoDePrecio(
                   new BigDecimal("8500.00"),
                   new BigDecimal("12000.00")
           );

   /* List<Producto> productosPorRango =
           productoRepository.findByPrecioBetween(
                   new BigDecimal("8500.00"),
                   new BigDecimal("12000.00")
           );
    */
   productosPorRango.forEach(System.out::println);

   System.out.println(
           "\n=== Lista productos que contengan pizzas ==="
   );
   /**
    * findBy | Nombre | Containing | IgnoreCase
    *   ↓        ↓          ↓            ↓
    * buscar   atributo   contiene    ignora
    *                                mayúsculas/
    *                                minúsculas
    *
    *Select * from productos where like '%nombre%';
    *
    */

   List<Producto> productosPizza =
           productoService.buscarPorNombre("pizza");
  /* List<Producto> resultado =
           productoRepository
                   .findByNombreContainingIgnoreCase("pizza");
  */

   productosPizza.forEach(System.out::println);


   System.out.println(
           "\n=== PRODUCTOS CON PRECIO MENOR A $10.000 ==="
   );
   /**
    * findBy | Precio | LessThan
    *   ↓        ↓        ↓
    * buscar    campo    operador <
    *
    * SELECT *
    * FROM productos
    * WHERE precio < ?
    *
    */
   List<Producto> productosBaratos =
           productoService.buscarProductosMenoresA(
                   new BigDecimal("10000.00")
           );
   /*List<Producto> productosBaratos =
           productoRepository.findByPrecioLessThan(
                   new BigDecimal("10000.00")
           );*/
   productosBaratos.forEach(System.out::println);


   productoService
           .obtenerProductosActivos()
           .forEach(System.out::println);

   //productoRepository.findByActivoTrue().forEach(System.out::println);

   productoService.eliminarProducto(5L);


   productoService.actualizarStock(
           1L,
           25
   );

   System.out.println("Cantidad final: " + productoService.contarProductos());
  //System.out.println("\nCantidad final: "+ productoRepository.count());



  System.out.println("H2: http://localhost:8089/h2-console");
  System.out.println("JDBC: jdbc:h2:mem:deliverygo | usuario: sa | password: vacio");

   System.out.println("\n=== PRODUCTOS CON PRECIO MENOR A $10.000 ===");
 };
 }}
