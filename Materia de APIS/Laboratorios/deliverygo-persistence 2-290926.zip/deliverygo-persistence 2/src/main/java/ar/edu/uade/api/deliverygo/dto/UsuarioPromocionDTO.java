package ar.edu.uade.api.deliverygo.dto;

import java.math.BigDecimal;

public class UsuarioPromocionDTO {

    private UsuarioDTO usuario;
    private PromocionDTO promocion;
    private BigDecimal descuentoAplicado;

    public UsuarioPromocionDTO(UsuarioDTO usuario, PromocionDTO promocion, BigDecimal descuentoAplicado) {
        this.usuario = usuario;
        this.promocion = promocion;
        this.descuentoAplicado = descuentoAplicado;
    }

    public UsuarioDTO getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioDTO usuario) {
        this.usuario = usuario;
    }

    public PromocionDTO getPromocion() {
        return promocion;
    }

    public void setPromocion(PromocionDTO promocion) {
        this.promocion = promocion;
    }

    public BigDecimal getDescuentoAplicado() {
        return descuentoAplicado;
    }

    public void setDescuentoAplicado(BigDecimal descuentoAplicado) {
        this.descuentoAplicado = descuentoAplicado;
    }
}
