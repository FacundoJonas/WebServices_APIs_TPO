package ar.edu.uade.api.deliverygo.model;

import jakarta.persistence.*;

@Entity
@Table(name = "direcciones")
public class Direccion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String calle;

    @Column(nullable = false)
    private int numero;

    @Column
    private String barrio;

    @ManyToOne
    @JoinColumn(name = "usuario_id" )
    private Usuario usuario;


    public Direccion() {
    }

    public Direccion(Long id, String calle, int numero, String barrio) {
        this.id = id;
        this.calle = calle;
        this.numero = numero;
        this.barrio = barrio;
    }

    public Direccion(Long id, String calle, int numero, String barrio, Usuario usuario) {
        this.id = id;
        this.calle = calle;
        this.numero = numero;
        this.barrio = barrio;
        this.usuario = usuario;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getBarrio() {
        return barrio;
    }

    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public String toString() {
        return "Direccion{" +
                "id=" + id +
                ", calle='" + calle + '\'' +
                ", numero=" + numero +
                ", barrio='" + barrio + '\'' +
                ", usuario=" + usuario +
                '}';
    }
}
