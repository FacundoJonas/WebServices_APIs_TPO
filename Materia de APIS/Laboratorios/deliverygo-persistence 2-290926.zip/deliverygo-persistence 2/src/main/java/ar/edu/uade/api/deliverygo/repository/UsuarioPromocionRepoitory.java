package ar.edu.uade.api.deliverygo.repository;

import ar.edu.uade.api.deliverygo.model.UsuarioPromocion;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UsuarioPromocionRepoitory extends JpaRepository<UsuarioPromocion,Long> {

    public List<UsuarioPromocion> findByUsuarioId(Long usuarioId);

    public List<UsuarioPromocion> findByPromocionId(Long promocionId);

}
