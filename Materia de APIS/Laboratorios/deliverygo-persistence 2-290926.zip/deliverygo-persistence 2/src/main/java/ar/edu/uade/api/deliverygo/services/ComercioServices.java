package ar.edu.uade.api.deliverygo.services;

import ar.edu.uade.api.deliverygo.dto.ComercioDto;
import ar.edu.uade.api.deliverygo.excepcion.RecursoDuplicadoException;
import ar.edu.uade.api.deliverygo.excepcion.RecursoNoEncontradoException;
import ar.edu.uade.api.deliverygo.excepcion.ReglaNegocioException;
import ar.edu.uade.api.deliverygo.model.Comercio;
import ar.edu.uade.api.deliverygo.repository.ComercioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

@Service
public class ComercioServices {


    private final ComercioRepository comercioRepository;

    private static final boolean isComercioActive = true;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
            );

    public ComercioServices(ComercioRepository comercioRepository) {
        this.comercioRepository = comercioRepository;

    }


    @Transactional
    public ComercioDto crearComercio(ComercioDto comercioDto){


        String cuit = comercioDto.getCuitComercio();
        if(Objects.isNull(cuit) || cuit.isEmpty()){
            throw new ReglaNegocioException("El CUIT del comercio no puede ser nulo");
        }
         if(comercioRepository.
                 findByCuit(comercioDto.getCuitComercio()).isPresent())
         {
             throw new RecursoDuplicadoException("El CUIT del comercio ya existe");
         }
        String nombreComercio = comercioDto.getNombreComercio();
        if (Objects.isNull(nombreComercio) || nombreComercio.isEmpty()){
            throw new ReglaNegocioException("El nombre del comercio no puede ser nulo");
        }
        String email = validateEmail(comercioDto.getEmailComercio());
        Comercio c = new Comercio(nombreComercio, cuit,email, isComercioActive);
        comercioRepository.save(c);
        return comercioDto;
    }


    private String validateEmail(String email) {
        if (Objects.isNull(email) || email.isEmpty()) {
            throw new ReglaNegocioException("El email del comercio no puede ser nulo");
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new ReglaNegocioException(
                    "El formato del email es inválido"
            );
        }
        return email;
    }

    @Transactional(readOnly = true)
    public ComercioDto buscarPorCuit(
            String cuit) {

        return convertirDTO(
                buscarEntidadPorCuit(cuit)
        );
    }


    @Transactional
    public ComercioDto modificarComercio(String cuitIn, ComercioDto dto) {

        String cuit = dto.getCuitComercio();
        if(Objects.isNull(cuit) || cuit.isEmpty()){
            throw new ReglaNegocioException("El CUIT del comercio no puede ser nulo");
        }

        Comercio comercio =
                buscarEntidadPorCuit(cuitIn);

        if(Objects.isNull(comercio))
        {
            throw new ReglaNegocioException("El CUIT del comercio no existe");
        }
        String nombreComercio = dto.getNombreComercio();
        if (Objects.isNull(nombreComercio) || nombreComercio.isEmpty()){
            throw new ReglaNegocioException("El nombre del comercio no puede ser nulo");
        }
        String email = validateEmail(dto.getEmailComercio());

        comercio.setNombre(dto.getNombreComercio());
        comercio.setEmail(email);


        return convertirDTO(comercio);
    }

    @Transactional(readOnly=true)
    public List<ComercioDto> buscarTodos() {
        return comercioRepository
                .findAll()
                .stream()
                .map(this::convertirDTO)
                .toList();
    }


    private Comercio buscarEntidadPorCuit(
            String cuit) {

        return comercioRepository.findByCuit(cuit).orElseThrow(
                        () -> new RecursoNoEncontradoException(
                                "No existe comercio con CUIT " + cuit
                        )
                );
    }

    private ComercioDto convertirDTO(
            Comercio comercio) {

        return new ComercioDto(
                comercio.getNombre(),
                comercio.getCuit(),
                comercio.getEmail()
        );
    }

    @Transactional
    public void desactivar(
            String cuit) {

        Comercio comercio =
                buscarEntidadPorCuit(cuit);

        if (!comercio.getActivo()) {
            throw new ReglaNegocioException(
                    "El comercio ya se encuentra inactivo"
            );
        }

        comercio.setActivo(false);
    }
}
