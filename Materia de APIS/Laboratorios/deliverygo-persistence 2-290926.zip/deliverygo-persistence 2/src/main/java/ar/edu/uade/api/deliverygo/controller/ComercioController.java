package ar.edu.uade.api.deliverygo.controller;

import ar.edu.uade.api.deliverygo.dto.ComercioDto;
import ar.edu.uade.api.deliverygo.services.ComercioServices;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/v1/comercios")
/*  Post  http://localhost:8080/v1/comercios
*  Entrada
*  {
*        nombreComercio: "Comercio 1",
*        cuitComercio: "20-12345678-9",
*         emailComercio: "ale@gmial.com"
*      }
*Respuesta
*
*
*   Get  http://localhost:8080/v1/comercios/{id}
*   Delete  http://localhost:8080/v1/comercios/{id}
*
* */

public class ComercioController {

    private final ComercioServices comercioServices;

    public ComercioController(ComercioServices comercioServices) {
        this.comercioServices = comercioServices;
    }

    @PostMapping
    public ResponseEntity<ComercioDto> crearComercio(
            @RequestBody ComercioDto comercioDto) {

        comercioServices.crearComercio(comercioDto);
        // Lógica para crear un comercio
        return ResponseEntity.status(HttpStatus.CREATED).body(comercioDto);
    }

    @GetMapping
    public ResponseEntity<List<ComercioDto>>
    listar() {

        return ResponseEntity.ok(
                comercioServices.buscarTodos()
        );
    }

        @GetMapping("/{cuit}")
        public ResponseEntity<ComercioDto>
        buscarPorCuit(
                @PathVariable String cuit) {

            return ResponseEntity.ok(
                    comercioServices.buscarPorCuit(cuit)
            );
        }

    @PutMapping("/{cuit}")
    public ResponseEntity<ComercioDto> modificarComercio(
            @PathVariable String cuit, @RequestBody ComercioDto dto) {

        ComercioDto comercioDto = comercioServices.modificarComercio(cuit, dto);
        // Lógica para crear un comercio
        return ResponseEntity.status(HttpStatus.OK).body(comercioDto);
    }

    @DeleteMapping("/{cuit}")
    public ResponseEntity<Void>
    eliminar(
            @PathVariable String cuit) {

        comercioServices.desactivar(cuit);

        return ResponseEntity
                .noContent()
                .build();
    }

}
