package ar.edu.uade.api.deliverygo.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name="productos")
public class Producto {

   @Id
   @GeneratedValue(strategy=GenerationType.IDENTITY)
   private Long id;

   @Column(nullable=false)
   private String nombre;

   private String descripcion;

   @Column(nullable=false,precision=12,scale=2)
   private BigDecimal precio;

   @Column(nullable=false)
   private Integer stock;

   @Column(nullable=false)
   private Boolean activo;

   @ManyToOne
   @JoinColumn(name = "comercio_id")
   private Comercio comercio;

   public void setComercio(Comercio comercio) {
    this.comercio = comercio;
   }

   public Comercio getComercio() {
    return comercio;
   }


   public Producto(){}

   public Producto(String n,String d,BigDecimal p,Integer s,Boolean a){
    nombre=n;descripcion=d;precio=p;stock=s;activo=a;
   }

   public Producto(String nombre, String descripcion, BigDecimal precio, Integer stock) {
      this.nombre = nombre;
      this.descripcion = descripcion;
      this.precio = precio;
      this.stock = stock;
   }

   public Producto(String n, String d, BigDecimal p, Integer s, Boolean a, Comercio c){
    nombre=n;descripcion=d;precio=p;stock=s;activo=a; comercio = c;
   }
   public void setStock(Integer s){
    stock=s;
   }

   @Override public String toString(){
    return "Producto{id="+id+", nombre='"+nombre+"', " +
            "precio="+precio+", stock="+stock+", activo="+activo+"}";}

   public Long getId() {
      return id;
   }

   public String getNombre() {
      return nombre;
   }

   public void setNombre(String nombre) {
      this.nombre = nombre;
   }

   public String getDescripcion() {
      return descripcion;
   }

   public void setDescripcion(String descripcion) {
      this.descripcion = descripcion;
   }

   public BigDecimal getPrecio() {
      return precio;
   }

   public void setPrecio(BigDecimal precio) {
      this.precio = precio;
   }

   public Integer getStock() {
      return stock;
   }

   public Boolean getActivo() {
      return activo;
   }

   public void setActivo(Boolean activo) {
      this.activo = activo;
   }
}