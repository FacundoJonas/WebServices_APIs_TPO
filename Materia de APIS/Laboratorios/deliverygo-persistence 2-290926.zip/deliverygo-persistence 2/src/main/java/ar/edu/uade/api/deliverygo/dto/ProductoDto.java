package ar.edu.uade.api.deliverygo.dto;

public class ProductoDto {


     private String nombreProducto;
     private double precio;;
     private  String descripcion;;
     private int stock;
    private String cuilComercio;

    public ProductoDto(String nombreProducto, double precio, String descripcion, int stock) {
        this.nombreProducto = nombreProducto;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
    }

    public ProductoDto(String nombreProducto, double precio, String descripcion, int stock, String cuilComercio) {
        this.nombreProducto = nombreProducto;
        this.precio = precio;
        this.descripcion = descripcion;
        this.stock = stock;
        this.cuilComercio = cuilComercio;
    }
    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    @Override
    public String toString() {
        return "ProductoDto{" +
                "nombreProducto='" + nombreProducto + '\'' +
                ", precio=" + precio +
                ", descripcion='" + descripcion + '\'' +
                ", stock=" + stock +
                '}';
    }

    public String getCuilComercio() {
        return cuilComercio;
    }
}
