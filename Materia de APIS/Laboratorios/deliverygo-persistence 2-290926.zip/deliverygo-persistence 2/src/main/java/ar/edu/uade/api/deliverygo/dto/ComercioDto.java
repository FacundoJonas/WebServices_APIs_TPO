package ar.edu.uade.api.deliverygo.dto;

public class ComercioDto {

    private String nombreComercio;

    private String cuitComercio;

    private String emailComercio;

    public ComercioDto(String nombreComercio, String cuitComerio, String emailComercio) {
        this.nombreComercio = nombreComercio;
        this.cuitComercio = cuitComerio;
        this.emailComercio = emailComercio;
    }

    public String getNombreComercio() {
        return nombreComercio;
    }

    public void setNombreComercio(String nombreComercio) {
        this.nombreComercio = nombreComercio;
    }

    public String getCuitComercio() {
        return cuitComercio;
    }

    public void setCuitComercio(String cuitComercio) {
        this.cuitComercio = cuitComercio;
    }

    public String getEmailComercio() {
        return emailComercio;
    }

    public void setEmailComercio(String emailComercio) {
        this.emailComercio = emailComercio;
    }

    @Override
    public String toString() {
        return "ComercioDto{" +
                "nombreComercio='" + nombreComercio + '\'' +
                ", cuitComerio='" + cuitComercio + '\'' +
                ", emailComercio='" + emailComercio + '\'' +
                '}';
    }
}
