package ar.edu.uade.api.deliverygo.dto;

import java.math.BigDecimal;

public class PromocionDTO {

    private String descripcion;
    private BigDecimal monto;


    public PromocionDTO(String descripcion, BigDecimal monto) {
        this.descripcion = descripcion;
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public BigDecimal getMonto() {
        return monto;
    }

    public void setMonto(BigDecimal monto) {
        this.monto = monto;
    }
}
