package ar.edu.uade.api.deliverygo.excepcion;

public class RecursoDuplicadoException extends RuntimeException{

        public RecursoDuplicadoException(String message){
            super(message);
        }
}
