package ar.edu.uade.api.deliverygo.excepcion;

import ar.edu.uade.api.deliverygo.dto.ErrorResponseDto;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(
            RecursoNoEncontradoException.class
    )
    public ResponseEntity<ErrorResponseDto>
    manejarNoEncontrado(
            RecursoNoEncontradoException ex,
            HttpServletRequest request) {

        ErrorResponseDto error =
                new ErrorResponseDto(
                        LocalDateTime.now(),
                        HttpStatus.NOT_FOUND.value(),
                        "NOT_FOUND",
                        ex.getMessage(),
                        request.getRequestURI()
                );

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(error);
    }

    @ExceptionHandler(
            RecursoDuplicadoException.class
    )
    public ResponseEntity<ErrorResponseDto>
    manejarDuplicado(
            RecursoDuplicadoException ex,
            HttpServletRequest request) {

        ErrorResponseDto error =
                new ErrorResponseDto(
                        LocalDateTime.now(),
                        HttpStatus.CONFLICT.value(),
                        "CONFLICT",
                        ex.getMessage(),
                        request.getRequestURI()
                );

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(error);
    }



    @ExceptionHandler(
            ReglaNegocioException.class
    )
    public ResponseEntity<ErrorResponseDto>
    manejarReglaNegocio(
            ReglaNegocioException ex,
            HttpServletRequest request) {

        ErrorResponseDto error =
                new ErrorResponseDto(
                        LocalDateTime.now(),
                        HttpStatus.BAD_REQUEST.value(),
                        "BAD_REQUEST",
                        ex.getMessage(),
                        request.getRequestURI()
                );

        return ResponseEntity
                .badRequest()
                .body(error);
    }
}
