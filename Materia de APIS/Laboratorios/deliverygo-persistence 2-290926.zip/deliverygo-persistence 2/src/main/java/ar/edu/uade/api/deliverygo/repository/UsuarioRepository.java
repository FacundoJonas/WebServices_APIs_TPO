package ar.edu.uade.api.deliverygo.repository;

import ar.edu.uade.api.deliverygo.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepository extends JpaRepository<Usuario,Long> {

    boolean existsByEmail(String email);

}
