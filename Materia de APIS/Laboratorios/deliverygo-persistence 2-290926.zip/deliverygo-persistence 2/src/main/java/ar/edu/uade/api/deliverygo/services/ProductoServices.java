package ar.edu.uade.api.deliverygo.services;

import ar.edu.uade.api.deliverygo.dto.ProductoDto;
import ar.edu.uade.api.deliverygo.model.Comercio;
import ar.edu.uade.api.deliverygo.model.Producto;
import ar.edu.uade.api.deliverygo.repository.ComercioRepository;
import ar.edu.uade.api.deliverygo.repository.ProductoRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class ProductoServices {

    private final ProductoRepository productoRepository;

    private final ComercioRepository comercioRepository;

    private static final boolean isProductoActive = true;

    public ProductoServices(ProductoRepository productoRepository, ComercioRepository comercioRepository) {
        this.productoRepository = productoRepository;
        this.comercioRepository = comercioRepository;
    }

    @Transactional
    public ProductoDto createProducto(ProductoDto productoDto) {

        Producto producto = validateProducto(productoDto);
        producto.setActivo(isProductoActive);
        Optional<Comercio> c = comercioRepository.findByCuit(productoDto.getCuilComercio());
        producto.setComercio(c.orElse(null));
        productoRepository.save(producto);
        return productoDto;
    }

    private Producto validateProducto(ProductoDto productoDto){

        String nombre = productoDto.getNombreProducto();
        if(Objects.isNull(nombre) || nombre.isEmpty()){
            throw new IllegalArgumentException("El nombre del producto no puede ser nulo");
        }
        String descripcion = productoDto.getDescripcion();
        if(Objects.isNull(descripcion) || descripcion.isEmpty()){
            throw new IllegalArgumentException("La descripcion del producto no puede ser nula");
        }
        BigDecimal precio = BigDecimal.valueOf(productoDto.getPrecio());
        if(precio.compareTo(BigDecimal.ZERO) <= 0){
            throw new IllegalArgumentException("El precio del producto no puede ser nulo o menor o igual a cero");
        }
        int stock = productoDto.getStock();
        if(stock < 0){
            throw new IllegalArgumentException("El stock del producto no puede ser menor a cero");
        }
        return new Producto(nombre,descripcion,precio,stock);
    }

    public List<Producto> obtenerTodos() {
        return productoRepository.findAll();
    }

    public List<Producto> buscarPorRangoDePrecio(
            BigDecimal precioMinimo,
            BigDecimal precioMaximo) {

        return productoRepository.findByPrecioBetween(
                precioMinimo,
                precioMaximo
        );
    }

    public List<Producto> obtenerProductosActivos() {

        return productoRepository.findByActivoTrue();
    }

    public List<Producto> buscarPorNombre(String nombre) {

        return productoRepository
                .findByNombreContainingIgnoreCase(nombre);
    }

    public List<Producto> buscarProductosMenoresA(BigDecimal precio) {

        return productoRepository.findByPrecioLessThan(precio);
    }

    @Transactional
    public void actualizarStock(Long productoId, Integer nuevoStock) {

        Producto producto = productoRepository
                .findById(productoId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Producto no encontrado: " + productoId
                        )
                );

        producto.setStock(nuevoStock);

        productoRepository.save(producto);
    }


    public long contarProductos() {
        return productoRepository.count();
    }

    @Transactional
    public void eliminarProducto(Long productoId) {

        Producto producto = productoRepository
                .findById(productoId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Producto no encontrado: " + productoId
                        )
                );

        productoRepository.delete(producto);
    }
}
