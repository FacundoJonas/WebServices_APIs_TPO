package ar.edu.uade.api.deliverygo.services;

import ar.edu.uade.api.deliverygo.dto.UsuarioPromocionDTO;
import ar.edu.uade.api.deliverygo.model.Promocion;
import ar.edu.uade.api.deliverygo.model.Usuario;
import ar.edu.uade.api.deliverygo.model.UsuarioPromocion;
import ar.edu.uade.api.deliverygo.repository.PromocionRepository;
import ar.edu.uade.api.deliverygo.repository.UsuarioPromocionRepoitory;
import ar.edu.uade.api.deliverygo.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.regex.Pattern;


@Service
public class PromocionUsuarioServices {


    private final PromocionRepository promocionRepository;

    private final UsuarioRepository usuarioRepository;

    private final UsuarioPromocionRepoitory usuarioPromocionRepoitory;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile(
                    "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
            );

    public PromocionUsuarioServices(PromocionRepository promocionRepository,
                                    UsuarioRepository usuarioRepository,
                                    UsuarioPromocionRepoitory usuarioPromocionRepoitory) {
        this.promocionRepository = promocionRepository;
        this.usuarioRepository = usuarioRepository;
        this.usuarioPromocionRepoitory = usuarioPromocionRepoitory;
    }

    @Transactional
    public void agregarUsuarioConSuPromocion(UsuarioPromocionDTO dto){


        String email = validateEmail(dto.getUsuario().getEmail());
        if (usuarioRepository.existsByEmail(email)) {
            throw new IllegalArgumentException(
                    "Ya existe un usuario con el email ingresado"
            );
        }

        if (dto.getDescuentoAplicado().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException(
                    "El descuento debe ser mayor a cero"
            );
        }

        Usuario usuario = new Usuario(
                dto.getUsuario().getEmail(),
                dto.getUsuario().getNombre(),
                dto.getUsuario().getApellido()
        );

        usuarioRepository.save(usuario);

        Promocion promocion = new Promocion(
                dto.getPromocion().getDescripcion(),
                dto.getPromocion().getMonto()
        );

        promocionRepository.save(promocion);

        UsuarioPromocion usuarioPromocion = new UsuarioPromocion();

        usuarioPromocion.setUsuario(usuario);
        usuarioPromocion.setPromocion(promocion);
        usuarioPromocion.setFechaPromocionUso(LocalDateTime.now());
        usuarioPromocion.setDescuentoAplicado(dto.getDescuentoAplicado());

        usuarioPromocionRepoitory.save(usuarioPromocion);
    }

    private String validateEmail(String email) {
        if (Objects.isNull(email) || email.isEmpty()) {
            throw new IllegalArgumentException("El email del comercio no puede ser nulo");
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new IllegalArgumentException(
                    "El formato del email es inválido"
            );
        }
        return email;
    }
}
