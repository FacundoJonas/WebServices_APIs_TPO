package ar.edu.uade.api.deliverygo.repository;

import ar.edu.uade.api.deliverygo.model.Promocion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PromocionRepository extends JpaRepository<Promocion, Long> {
}
